let hours_worked = [ 30; 30; 30; 30 ]
